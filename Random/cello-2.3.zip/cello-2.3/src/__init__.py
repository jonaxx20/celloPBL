from .version import version, author

__title__ = 'Cello'
__version__ = version
__author__ = author
