
class Scheduler(object):
    def __init__(self):
        pass

    def get_one(self, prefer):
        return {}


class HostScheduler(Scheduler):

    def __init__(self):
        pass

    def get_host(self):
        return {}
