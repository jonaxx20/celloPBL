version = "2.0.0-rc2"
version_info = tuple([int(d) for d in version.split("-")[0].split(".")])
author = "Baohua Yang <baohyang@cn.ibm.com>"
homepage = "https://yeasy.github.com"
